deploy_and_restart()
{
	TOMCAT_HOME=$1
	BUILD_LOCATION=$2
	echo Deploy and restart for $TOMCAT_HOME with $BUILD_LOCATION/*.war

	cd $TOMCAT_HOME
	bin/shutdown.sh
	cd -

	sleep 5

	rm -rf $TOMCAT_HOME/webapps/ROOT*
	cp -f Radix/bundles/$BUILD_LOCATION/target/*.war $TOMCAT_HOME/webapps/ROOT.war

	cd $TOMCAT_HOME
	bin/startup.sh
	cd -
}

deploy_and_restart ~/of_radix/tomcat_radix_api service-controller/service-controller-service-component
deploy_and_restart ~/of_radix/tomcat_radix_auth gears/oauth2
