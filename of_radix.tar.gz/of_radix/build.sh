# clear old mavne repository
rm -rf ~/.m2/repository/com/kthcorp/radix

# build all
cd Radix
mvn -e -DskipTests clean install
cd -

# make war for api.pudding.to
cd Radix/bundles/service-controller/service-controller-service-component
mvn -e -DskipTests assembly:single
cd -

# make war for auth.pudding.to
cd Radix/bundles/gears/oauth2
mvn -e -DskipTests assembly:single
cd -


