# TODO : remove DEV
PATH=/home/ec2-user/.rvm/gems/ruby-1.9.3-p194/bin:/home/ec2-user/.rvm/gems/ruby-1.9.3-p194@global/bin:/home/ec2-user/.rvm/rubies/ruby-1.9.3-p194/bin:/home/ec2-user/.rvm/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/opt/aws/bin:/home/ec2-user/server/apache-maven-3.0.3/bin/:/home/ec2-user/.rvm/bin:/home/ec2-user/bin:.
export PATH=$JAVA_HOME/bin:$PATH
export MAVEN_HOME=~/server/apache-maven-3.0.3
