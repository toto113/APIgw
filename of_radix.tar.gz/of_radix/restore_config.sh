cp config_backup/spring-dao-mysql-context.xml Radix/bundles/common/common-config/src/main/resources/META-INF/spring/
cp config_backup/api-log4j.xml Radix/bundles/common/common-config/src/main/resources/log4j.xml
cp config_backup/auth-log4j.xml Radix/bundles/gears/oauth2/src/main/resources/log4j.xml
cp config_backup/application-context.properties Radix/bundles/common/common-config/src/main/resources/
cp config_backup/hazelcast.xml Radix/bundles/common/common-config/src/main/resources/
cp config_backup/hazelcast-test.xml Radix/bundles/common/common-config/src/main/resources/
