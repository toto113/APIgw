mkdir config_backup 2>/dev/null
cp Radix/bundles/common/common-config/src/main/resources/META-INF/spring/spring-dao-mysql-context.xml config_backup/
cp Radix/bundles/common/common-config/src/main/resources/log4j.xml config_backup/api-log4j.xml
cp Radix/bundles/gears/oauth2/src/main/resources/log4j.xml config_backup/auth-log4j.xml
cp Radix/bundles/common/common-config/src/main/resources/application-context.properties config_backup/
cp Radix/bundles/common/common-config/src/main/resources/hazelcast.xml config_backup/
cp Radix/bundles/common/common-config/src/main/resources/hazelcast-test.xml config_backup/
